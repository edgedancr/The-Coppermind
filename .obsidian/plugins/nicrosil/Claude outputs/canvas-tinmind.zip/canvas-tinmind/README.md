# Canvas Tinmind

A personal Chrome extension that restyles phc.instructure.com in the Tinmind look
(charcoal and lilac, gradient titles, square corners). It only changes how pages look in your own browser.

## Install (unpacked)
1. Unzip this folder somewhere permanent (Chrome reads it from there each time it starts).
2. Open chrome://extensions and switch on "Developer mode" (top right).
3. Click "Load unpacked" and pick the unzipped `canvas-tinmind` folder.
4. Open https://phc.instructure.com/ (reload if it was already open).

## Turn it off
Click the extension's toolbar icon and untick "Theme on". Nothing else is changed.
Quizzes (take/questions pages and borderless launches) are never themed.

## Files
- manifest.json: scopes the extension to phc.instructure.com
- theme.css: the whole look, every rule under `html.tm-on`
- content.js: adds/removes the `tm-on` class; skips quizzes
- popup.html / popup.js: the on/off switch
