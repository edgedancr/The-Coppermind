// Canvas Tinmind: switches the theme on by adding a class to <html>.
// All of theme.css is scoped under html.tm-on, so removing the class restores stock Canvas.
(() => {
  const html = document.documentElement;
  const url = location.pathname + location.search;

  // Never theme quizzes or proctored pages: timed quizzes, new-quiz launches, lockdown/borderless views.
  const skip =
    /\/quizzes\/\d+\/(take|questions|history)/.test(url) ||
    /[?&]display=borderless/.test(url) ||
    /lockdown/i.test(url);
  if (skip) return;

  // Turn on immediately to avoid a flash of the old look, then honour the saved setting.
  html.classList.add('tm-on');
  try {
    chrome.storage.sync.get({ enabled: true }, (s) => {
      html.classList.toggle('tm-on', s.enabled !== false);
    });
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.enabled) html.classList.toggle('tm-on', changes.enabled.newValue !== false);
    });
  } catch (e) {
    /* storage unavailable: leave the theme on */
  }
})();
